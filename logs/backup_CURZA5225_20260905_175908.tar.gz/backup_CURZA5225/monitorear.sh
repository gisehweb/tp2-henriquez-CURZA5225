#!/bin/bash
# Trabajo Práctico 2 - Automatización y Scripting
# Alumna: Gisella Henriquez - Legajo CURZA5225
# Script: monitorear.sh
# Objetivo: Panel interactivo de monitoreo de recursos

PS3="Seleccione una opción: "

while true; do
    select opcion in "Monitorear RAM" "Buscar archivos grandes" "Espacio en particiones" "Salir"; do
        case $REPLY in
            1)
                echo "📌 Monitoreo de RAM (MB):"
                free -m
                break
                ;;
            2)
                echo "📌 Archivos mayores a 10MB en $HOME (top 5):"
                find "$HOME" -type f -size +10M -exec du -h {} + 2>/dev/null | sort -rh | head -n 5
                break
                ;;
            3)
                echo "📌 Uso de disco en particiones físicas:"
                df -h --type=ext4 --type=xfs
                break
                ;;
            4)
                echo "👋 Gracias por usar el monitoreo. Alumna CURZA5225"
                exit 0
                ;;
            *)
                echo "Opción inválida."
                break
                ;;
        esac
    done
done
